# CyberLens AI — Streamlit Edition

AI-powered digital evidence analysis and cybercrime awareness platform.  
Aligned with **SDG 16** (Peace, Justice & Strong Institutions) and **SDG 9** (Industry, Innovation & Infrastructure).

## Features

- **Quick Analyzer** — paste any suspicious text/email/message and get an instant AI risk score
- **Investigations** — create cases and group related evidence
- **Evidence Ingestion** — upload CSV, JSON, or plain-text files; paste raw content
- **AI Threat Analysis** — OpenAI GPT-4o-mini scores risk (0–100), detects phishing/scam/fraud/malware, extracts entities and timeline events
- **Network Graph** — visualises relationships between extracted entities
- **Intelligence Reports** — AI-generated boardroom-ready summaries
- **Command Center Dashboard** — live charts, stats cards, and activity feed

## Deploy on Streamlit Cloud (free)

### Step 1 — Push to GitHub

Push the contents of this folder to your GitHub repo  
(`https://github.com/Aishu1312/CyberLensAI`).

The repo root should look like:

```
app.py
requirements.txt
utils.py
pages/
  __init__.py
  home.py
  dashboard.py
  investigations.py
  upload.py
  analyze.py
  reports.py
  about.py
.streamlit/
  config.toml
```

### Step 2 — Create a Streamlit Cloud app

1. Go to **https://share.streamlit.io** → **New app**
2. Connect your GitHub account and select `Aishu1312/CyberLensAI`
3. Set **Main file path** to `app.py`
4. Click **Advanced settings** → **Secrets** and add:

```toml
OPENAI_API_KEY = "sk-..."
```

5. Click **Deploy**. Done — your app is live at a `.streamlit.app` URL.

## Run locally

```bash
pip install -r requirements.txt
# Create a .env file with: OPENAI_API_KEY=sk-...
# OR add it to .streamlit/secrets.toml: OPENAI_API_KEY = "sk-..."
streamlit run app.py
```

## Stack

| Layer | Technology |
|---|---|
| UI | Streamlit 1.35+ |
| AI | OpenAI GPT-4o-mini |
| Charts | Plotly |
| Data | Python session state (in-memory) |
| Styling | Custom CSS injected via `st.markdown` |

> **Note:** This Streamlit version uses in-memory session state — data resets on page refresh.  
> For persistence, connect a database (e.g. Supabase free tier) and adapt `utils.py`.
